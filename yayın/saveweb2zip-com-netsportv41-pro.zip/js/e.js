(function (w,d){
  if (void 0 === w.ABN) {
  var _eScript = d.currentScript;
function a(n,p){
if(this instanceof a&&!a.zones[n]){
if(!(b=d.getElementById(n))||!p.id)return null
var z=this
z.name=n
z.id=p.id
a.merge(z,{div:b,param:p,state:0})
a.zones[n]=z
if(p.domain)z.domain="https://z.cdn."+p.domain+"/"
p.noload||z.load()
}
return a.zones[n]
}
a.prototype={
load: function(){
var z=this,dc="CSS1Compat"==d.compatMode?d.documentElement:d.body
if(!a.ready){if(a.pending.indexOf(z)<0)a.pending.push(z);return}
z.s&&z.write("")
a.run((z.domain?z.domain:a.domain)+"load?z="+z.param.id+"&div="+z.name+"&cw="+dc.clientWidth+"&ch="+dc.clientHeight+a.q,function(){z.s=2})
z.s=1
},
write:function(e){if(this.div)this.div.innerHTML=e},
append:function(e){this.div.appendChild(e)}
}
a.merge = function(){var r,n,e=arguments[0]||{};for(i=1;i<arguments.length;i++)if(null!=(r=arguments[i]))for(n in r)r.hasOwnProperty(n)&&void 0!==r[n]&&(e[n]=r[n]);return e},
a.ce=function(t){return document.createElement(t)},
a.replaceAll=function(t,s,r){return t.replace(new RegExp(s,'g'),r)},
a.makeid=function(l){var t="",p="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";while(t.length<l){t+=p.charAt(Math.floor(Math.random()* p.length))}return t},
a.getKey=function(){var c=Math.abs(Date.now()-Date.UTC(2e3));return String.fromCharCode(97+Math.floor((c/1e10)%10))+(c/1e7).toFixed(0)},
a.checkVar=function(e,d){return (null==e||typeof e==='undefined'||e==="")?d:e}
a.cleanZone = function(zid,s=''){d.querySelectorAll((s!=='')?s:'#zone_'+zid).forEach(function(e){while(e.firstChild){e.removeChild(e.firstChild)}})}
a.rebuildZone = function(zid, s= ''){var p,zn;for(var z of Object.values(a.zones)){if(zid == z.id){p=z.param;zn = z.name;delete a.zones[zn];break;}}a.cleanZone(zid,s);new a(zn,p)}
a.isMobile = function(z){return z instanceof Object && z.os ? [6,12,13,14,16,17,18,19,20,21,22].includes(z.os) : /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent||navigator.vendor||window.opera);}
a.getDMN =function(t){try {return (new URL(t)).hostname;}catch(e){return ""}}
a.getOffset = function(el){var x=0,y=0;while(el&&!isNaN(el.offsetLeft)&&!isNaN(el.offsetTop)){x+=el.offsetLeft-el.scrollLeft;y+=el.offsetTop-el.scrollTop;el=el.offsetParent;}return {top:y,left:x}}
a.getBlankImgSrc = function(){return 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII='}
a.bitToArray = function(val){var pows = new Array, pow = new Number;for(i = 0; i<10; i++){pow = 1 << i;if(pow & val){pows[i] = true}}return pows}
a.setSession = function(n,v){if(sessionStorage){sessionStorage.setItem(n,v)}if(localStorage){localStorage.setItem(n,v)}}
a.getSession = function(n){return localStorage?localStorage.getItem(n):(sessionStorage?sessionStorage.getItem(n):null)}
a.countView = function(m){if(m.view){(new Image()).src=m.view;m.view=null}a.countViewability(m)}
a.getMacros = function(t,m,dn="",dcn=""){
  t=t.replace(/%%DIV_NAME%%/g, dn).replace(/%%DIV_CLONE_NAME%%/g, dcn);
  if(m instanceof Object && m.path){t=t.replace(/%%DOMAIN%%/g, this.getDMN(m.path));}
  return t}

a.parseWidth = function(w,width) {
  if (typeof w === 'string' && w.startsWith('!')) {
  w = w.slice(1);
  const arr = w.split(',').map(entry => entry.split('-').map(Number));
  width = parseInt(width);
  return arr.find(entry => entry[0] < width && width <= entry[1])?.[2] || arr[arr.length - 1][2];
  } else {
    return parseInt(w);
  }
}

a.checkDeep = function (sn, z){
  if (!(z instanceof Object && z.deepBits) || typeof sessionStorage === 'undefined' || typeof z.deepBits === 'undefined') {
      return true;
    }
  const s = this.bitToArray(z.deepBits);
  const c = (parseInt(sessionStorage.getItem(sn)) || 0) + 1;
  sessionStorage.setItem(sn, c);
  return (c >= 7 && z.deepBits & (1 << 6)) >> 0 ? true : Boolean(s[c - 1]);
};
a.isNode = function (o){try{return o instanceof HTMLElement}catch(e){return (typeof o==="object")&&(o.nodeType===1)&&(typeof o.style === "object")&&(typeof o.ownerDocument ==="object")}}
a.viewabilityIAB = function (media) {
  if (media && a.isNode(media.node)) {
    let threshold = 0.5,delay = 1000,timer = null;

    if (media.node.offsetWidth * media.node.offsetHeight >= 242000) {
      threshold = 0.3;
      delay = 10;
    }

    const observer = new IntersectionObserver((entries, observer) => {
      entries.forEach(entry => {
        if (typeof media.viewability !== 'undefined' && media.viewability !== null && entry.isIntersecting) {
            clearTimeout(timer)
            timer = setTimeout(()=>{
              if(media.viewability){
                (new Image()).src = media.viewability;
                media.viewability = null;
                observer.unobserve(media.node);
              }
            }, delay)
        }else{
          clearTimeout(timer)
        }
      })
    }, {
      threshold
    });

    observer.observe(media.node)
  }
}

a.countViewability = function(m){
  if (m.node !== undefined) {
    switch (m.type) {
      case 'branding':
      case 'banner':
      default:
        if (m.viewability) {
          a.viewabilityIAB(m);
        }
        break;}}
}

var z=["SCRIPT","onreadystatechange","WEBGL","undefined"]
    a.run = function (e, f) {
      var st = z[0], s = d.createElement(st), t = d.getElementsByTagName(st)[0]
      s.async = true
      s.src = e
      if (f) s.onload = s[z[1]] = function (evt) { st = s.readyState; if (!st || st == "loaded" || st == "complete") { s.onload = s[z[1]] = null; f(s); } }
      t.parentNode.insertBefore(s, t)
    };
(function () {
      if (w.wf) return;
      var src = _eScript && _eScript.src;
      if (!src || src.includes("/media?m") ) {
        a.run("https://cdn.traffmovie.com/libs/wf.js");
      } else {
        a.run(src.replace(/[^/]*([?#].*)?$/, "") + "wf.js");
      }
    })();
function f(e,n){n=n||200;return(pos=e.indexOf("://"))>=0&&(e=e.substr(pos+3)),e.length>n&&(e=e.substr(0,n)),encodeURIComponent(e)}
a.q=""
a.fdt=300
a.ready=0
a.pending=[]
a.zones={}
a.protocol=w.location.protocol=="https:"?"https:":"http:"
a.h=w.ABNSh||"traffmovie.com"
a.domain="https://z.cdn."+a.h+"/"
w.ABNSl=w.ABNSl||[]
w.ABNSl.push=function(e){new a(e[0],e[1])}
w.ABN=a
var vc="0",t=new Date,ws=w.screen,mr=Math.round,hc=1,wn=w.navigator;
try{hc=wn.hardwareConcurrency}catch(p){hc=0}
try{var ca=d.createElement("canvas"),gl=ca.getContext("experimental-"+z[2].toLowerCase());
vc=gl.getParameter(gl.getExtension(z[2]+"_debug_renderer_info")["UNMASKED_RENDERER_"+z[2]])}catch(p){}
var mk = document.querySelector('meta[name="keywords"]'), md = document.querySelector('meta[name="description"]');
var ck = mk ? mk.getAttribute('content') : '', cd = md ? md.getAttribute('content') : '';
var scu="",scup="",scupv="",scum="";
try{var uad=wn.userAgentData;if(uad){if(uad.brands)scu=uad.brands.map(function(b){return b.brand+";v="+b.version}).join(", ");scup=uad.platform||""}}catch(p){}
    var FDU = "!u",
      FDB = "!b",
      FDT = "!t",
      FDE = "!e";
    function ft(fn, ms) {
      return new Promise(function (r) {
        var tm = setTimeout(function () {
          r(FDT);
        }, ms || a.fdt);
        new Promise(function (x) {
          x(fn());
        }).then(
          function (v) {
            clearTimeout(tm);
            r(v);
          },
          function () {
            clearTimeout(tm);
            r(FDE);
          },
        );
      });
    }
    function fh(s) {
      for (var i = 0, h = 0x811c9dc5; i < s.length; i++) {
        h ^= s.charCodeAt(i);
        h = Math.imul(h, 0x01000193);
      }
      return (h >>> 0).toString(36);
    }
    function fu(s) {
      if (s !== s) return "3";
      if (!isFinite(s)) return "2";
      if (s >= 18447) return "1";
      var u = BigInt(s.toFixed(15).replace(".", ""));
      return u > BigInt("18446744073709551615") ? "1" : u.toString();
    }
    function fmq(q) {
      try {
        return w.matchMedia(q).matches ? 1 : 0;
      } catch (e) {
        return 0;
      }
    }
    function fcv(c) {
      var x = c.getContext("2d");
      c.width = 220;
      c.height = 64;
      x.textBaseline = "alphabetic";
      x.fillStyle = "#3a7";
      x.fillRect(4, 6, 92, 30);
      x.fillStyle = "rgba(204,34,119,0.65)";
      x.font = "17px 'Times New Roman', serif";
      x.fillText("Sl,\u04167@ \u20b4 \ua66e \ud83d\ude03", 9, 28);
      x.shadowColor = "#06f";
      x.shadowBlur = 5;
      x.strokeStyle = "#b80";
      x.lineWidth = 2.5;
      x.beginPath();
      x.moveTo(110, 58);
      x.bezierCurveTo(140, -14, 176, 82, 214, 10);
      x.stroke();
      x.shadowBlur = 0;
      x.globalCompositeOperation = "difference";
      x.fillStyle = "#e9e";
      x.font = "bold 13px monospace";
      x.translate(120, 40);
      x.rotate(-0.21);
      x.fillText("\u01c4wm\u00c9g\u2042", 0, 0);
      return c.toDataURL();
    }
    function fst(n) {
      return function () {
        var k = "_abn_" + n.charAt(0);
        try {
          var s = w[n];
          if (!s) return 0;
          s.setItem(k, "1");
          s.removeItem(k);
          return 1;
        } catch (e) {
          return 2;
        }
      };
    }
    var fdFonts = [
      "Segoe UI", "Segoe Fluent Icons", "Bahnschrift", "Calibri", "Cambria",
      "Candara", "Corbel", "Constantia", "Ebrima", "Gadugi", "Sitka Text",
      "Javanese Text", "Leelawadee UI", "Malgun Gothic", "Microsoft YaHei",
      "Yu Gothic", "Nirmala UI", "MV Boli", "Myanmar Text", "HoloLens MDL2 Assets",
      "Helvetica Neue", "Avenir", "Avenir Next", "Menlo", "Gill Sans", "Futura",
      "Optima", "Didot", "Baskerville", "Hoefler Text", "Skia", "Chalkboard SE",
      "PingFang SC", "Apple SD Gothic Neo", "Hiragino Sans", "Kohinoor Devanagari",
      "Noteworthy", "DejaVu Sans", "Liberation Sans", "Ubuntu", "Noto Sans",
      "Cantarell", "Droid Sans", "Roboto", "FreeSans", "Source Sans Pro",
      "Open Sans", "Lato", "Adobe Garamond Pro", "Minion Pro",
    ];
    var fdGlobals = [
      "opr", "yandex", "__gCrWeb", "__firefox__", "ApplePaySession",
      "mozInnerScreenX", "samsungAr", "_phantom", "callPhantom", "__nightmare",
      "domAutomation", "domAutomationController", "Cypress", "__playwright__binding__",
      "__pwInitScripts", "_Selenium_IDE_Recorder", "__webdriver_evaluate",
      "__selenium_unwrapped", "__fxdriver_unwrapped", "spawn", "emit", "Buffer",
    ];
    var fdHints = ["architecture", "bitness", "model", "platformVersion"];
    var fd = {
      fdba: function () {
        var C = w.OfflineAudioContext || w.webkitOfflineAudioContext;
        if (!C) return FDU;
        var c = new C(1, 6000, 44100),
          o = c.createOscillator(),
          q = c.createBiquadFilter(),
          k = c.createDynamicsCompressor();
        o.type = "sawtooth";
        o.frequency.value = 2600;
        q.type = "lowpass";
        q.frequency.value = 3800;
        q.Q.value = 7;
        k.threshold.value = -36;
        k.knee.value = 12;
        k.ratio.value = 9;
        k.attack.value = 0.002;
        k.release.value = 0.2;
        o.connect(q);
        q.connect(k);
        k.connect(c.destination);
        o.start(0);
        return new Promise(function (r, j) {
          c.oncomplete = function (e) {
            r(e.renderedBuffer);
          };
          var p = c.startRendering();
          if (p && p.then) p.then(r, j);
        }).then(function (b) {
          var a = b.getChannelData(0),
            s = 0;
          for (var i = 3000; i < a.length; i++) s += Math.abs(a[i]);
          return fu(s);
        });
      },
      fdbc: function () {
        var c1 = d.createElement("canvas"),
          c2 = d.createElement("canvas");
        if (!c1.getContext || !c1.getContext("2d")) return FDU;
        var u = fcv(c1);
        return u === fcv(c2) ? fh(u) : FDB;
      },
      fdbfl: function () {
        var f = new Float32Array([Infinity]);
        f[0] = f[0] - f[0];
        return new DataView(f.buffer).getUint32(0, true) >>> 31;
      },
      fdbs: function () {
        return [
          Math.max(ws.width, ws.height),
          Math.min(ws.width, ws.height),
          ws.colorDepth,
        ].join("x");
      },
      fdbmq: function () {
        return [
          "(any-hover: hover)",
          "(pointer: fine)",
          "(pointer: coarse)",
          "(any-pointer: coarse)",
          "(dynamic-range: high)",
          "(color-gamut: p3)",
          "(color-gamut: rec2020)",
          "(prefers-reduced-motion: reduce)",
          "(forced-colors: active)",
          "(inverted-colors: inverted)",
          "(display-mode: standalone)",
        ]
          .map(fmq)
          .join("");
      },
      fdbck: function () {
        var n = "_abn_ck" + a.makeid(4);
        d.cookie = n + "=1; path=/; SameSite=Lax";
        var e = d.cookie.indexOf(n + "=1") !== -1;
        d.cookie = n + "=; path=/; max-age=0";
        return [wn.cookieEnabled ? 1 : 0, e ? 1 : 0].join("");
      },
      fdbn: function () {
        return [
          wn.platform,
          wn.vendor,
          wn.hardwareConcurrency,
          wn.deviceMemory,
          (wn.languages || [wn.language]).join(","),
          wn.webdriver ? 1 : 0,
          wn.oscpu || "",
          wn.pdfViewerEnabled ? 1 : 0,
          wn.userAgent,
        ].join("|");
      },
      fdbi: function () {
        if (!w.Intl || !w.Intl.DateTimeFormat) return FDU;
        var o = w.Intl.DateTimeFormat().resolvedOptions(),
          y = new Date().getFullYear();
        return [
          o.timeZone,
          o.locale,
          o.calendar,
          o.numberingSystem,
          new Date(y, 0, 1).getTimezoneOffset(),
          new Date(y, 6, 1).getTimezoneOffset(),
          w.Intl.NumberFormat ? w.Intl.NumberFormat().resolvedOptions().locale : "",
        ].join("|");
      },
      fdbf: function () {
        var x = d.createElement("canvas").getContext("2d");
        if (!x) return FDU;
        var t = "\u01c4wmi\ud835\udd01\u2042\u00c9g",
          gs = ["monospace", "sans-serif", "serif"],
          m = function (f) {
            x.font = "48px " + f;
            return x.measureText(t).width;
          },
          bw = gs.map(m);
        return fdFonts
          .filter(function (n) {
            return gs.some(function (g, i) {
              return m("'" + n + "'," + g) !== bw[i];
            });
          })
          .join(",");
      },
      fdbls: fst("localStorage"),
      fdbss: fst("sessionStorage"),
      fdbm: function () {
        var M = Math;
        return [
          M.sin(5.4e17),
          M.cos(-7.7e21),
          M.tan(3.3e13),
          M.atan2(0.3, -0.7),
          M.acosh(3.14e9),
          M.asinh(-6.6e-5),
          M.atanh(0.77),
          M.cbrt(5.1),
          M.expm1(-2.4e-7),
          M.log1p(7.7e-6),
          M.log10(M.PI * 1e7),
          M.log2(17),
          M.sinh(0.9),
          M.cosh(-12.1),
          M.tanh(0.37),
          M.hypot(1e154, 3e153),
          M.pow(M.E, -33.3),
        ].join(",");
      },
      fdbt: function () {
        return [
          wn.maxTouchPoints || 0,
          "ontouchstart" in w ? 1 : 0,
          typeof w.TouchEvent === "function" ? 1 : 0,
          fmq("(any-pointer: coarse)"),
        ].join("");
      },
      fdbu: function () {
        var u = wn.userAgentData;
        if (!u) return FDU;
        var r = {
          m: u.mobile ? 1 : 0,
          p: u.platform,
        };
        if (!u.getHighEntropyValues) return r;
        return u.getHighEntropyValues(fdHints).then(function (v) {
          r.a = v.architecture;
          r.b = v.bitness;
          r.md = v.model;
          r.pv = v.platformVersion;
          return r;
        });
      },
      fdbg: function () {
        return fdGlobals
          .filter(function (n) {
            try {
              return n in w;
            } catch (e) {
              return false;
            }
          })
          .join(",");
      },
      fdbw: function () {
        var c = d.createElement("canvas"),
          g = c.getContext("webgl") || c.getContext("experimental-webgl");
        if (!g) return FDU;
        var x = g.getExtension("WEBGL_debug_renderer_info"),
          lw = g.getParameter(g.ALIASED_LINE_WIDTH_RANGE),
          sp = g.getShaderPrecisionFormat(g.FRAGMENT_SHADER, g.HIGH_FLOAT);
        return {
          v: x ? g.getParameter(x.UNMASKED_VENDOR_WEBGL) : g.getParameter(g.VENDOR),
          r: x ? g.getParameter(x.UNMASKED_RENDERER_WEBGL) : g.getParameter(g.RENDERER),
          mt: g.getParameter(g.MAX_TEXTURE_SIZE),
          mr: g.getParameter(g.MAX_RENDERBUFFER_SIZE),
          mu: g.getParameter(g.MAX_VERTEX_UNIFORM_VECTORS),
          lw: lw ? lw[0] + "-" + lw[1] : "",
          sp: sp ? sp.rangeMax + "/" + sp.precision : "",
          ex: fh((g.getSupportedExtensions() || []).sort().join(",")),
        };
      },
      fdbdpr: function () {
        return w.devicePixelRatio || FDU;
      },
      fdbsq: function () {
        var s = wn.storage;
        if (!s || !s.estimate) return FDU;
        return s.estimate().then(function (e) {
          return e.quota;
        });
      },
      fdbsa: function () {
        if (!w.CSS || !CSS.supports || !CSS.supports("padding-top: env(safe-area-inset-top)"))
          return FDU;
        var e = d.createElement("div"),
          r = d.body || d.documentElement,
          sides = ["top", "right", "bottom", "left"];
        e.style.cssText =
          "position:fixed;left:0;top:0;width:0;height:0;visibility:hidden;pointer-events:none;padding:" +
          sides
            .map(function (n) {
              return "env(safe-area-inset-" + n + ")";
            })
            .join(" ");
        r.appendChild(e);
        var c = w.getComputedStyle(e),
          v = sides
            .map(function (n) {
              return parseFloat(c["padding-" + n]) || 0;
            })
            .join(",");
        r.removeChild(e);
        return v;
      },
    };
    function fdGpu() {
      if (!wn.gpu || !wn.gpu.requestAdapter) return FDU;
      return wn.gpu
        .requestAdapter()
        .then(function (ad) {
          if (!ad) return FDU;
          if (ad.info) return ad.info;
          return ad.requestAdapterInfo ? ad.requestAdapterInfo() : FDU;
        })
        .then(function (i) {
          if (typeof i === "string") return i;
          return [i.vendor, i.architecture, i.device, i.description]
            .filter(Boolean)
            .join(",");
        });
    }
    var fdOrder = [
      "fdbn",
      "fdbs",
      "fdbw",
      "fdbm",
      "fdbi",
      "fdbc",
      "fdbt",
      "fdbls",
      "fdba",
      "fdbmq",
      "fdbf",
      "fdbu",
      "fdbck",
      "fdbss",
      "fdbg",
      "fdbfl",
      "fdbdpr",
      "fdbsq",
      "fdbsa",
    ];
    function hd(s) {
      try {
        return w.crypto.subtle
          .digest("SHA-256", new TextEncoder().encode(s))
          .then(function (h) {
            return BigInt(
              "0x" +
                Array.from(new Uint8Array(h), function (x) {
                  return ("0" + x.toString(16)).slice(-2);
                }).join(""),
            ).toString();
          })
          .catch(function () {
            return "";
          });
      } catch (p) {
        return Promise.resolve("");
      }
    }
    var hb = "",
      hg = "",
      hf = "";
    function gb() {
      var t0 = Date.now();
      Promise.all(
        fdOrder
          .map(function (n) {
            return ft(fd[n]);
          })
          .concat(ft(fdGpu)),
      )
        .then(function (v) {
          a.fdd = { o: fdOrder, v: v, ms: Date.now() - t0 };
          var n = fdOrder.length,
            u = v[fdOrder.indexOf("fdbu")],
            gw = v[fdOrder.indexOf("fdbw")];
          if (u && u.pv !== undefined) {
            scupv = u.pv || "";
            scum = u.md || "";
          }
          if (gw && gw.r) vc = gw.r;
          hf = String(v[fdOrder.indexOf("fdba")]);
          hf = { "!t": "4", "!e": "5", "!u": "6" }[hf] || hf;
          hg = String(v[n]);
          return hd(JSON.stringify(v.slice(0, n)));
        })
        .then(function (h) {
          hb = h;
        })
        .catch(function () {})
        .then(go);
    }
function go(){
var p={
sr:ws.width+"x"+ws.height,
df:d.hasFocus&&d.hasFocus()+0,
tz:-t.getTimezoneOffset(),
bh:w.history.length,
tl:(pr=w.performance)&&void 0!==pr.now&&mr(pr.now()),
pl:wn.plugins&&wn.plugins.length,
mi:wn.mimeTypes&&wn.mimeTypes.length,
me:wn.deviceMemory,
hc:hc,
n:Date.now(),
v:w.self===w.top,
i:w.self===w.top,
scu:f(scu),scup:f(scup),scupv:f(scupv),scum:f(scum),
url:f(w.location.href),vc:f(vc),ref:f(d.referrer),ti:f(d.title,100)+","+f(ck,100)+","+f(cd,100),b:hb,g:f(hg),f:f(hf)};
for(k in p)if((v=p[k])&&v!=z[3]){a.q+="&"+k+"="+v}
for(i=0,v=0;i<a.q.length;i++){v=(((v<<5)-v)+a.q.charCodeAt(i))|0}
a.q+="&zyx="+(v>>>0)
a.ready=1
while(a.pending.length){a.pending.shift().load()}
while(w.ABNSl.length){e=w.ABNSl.pop();new a(e[0],e[1])}
}
gb()
}})(window,document)
